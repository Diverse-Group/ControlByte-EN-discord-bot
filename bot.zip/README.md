# ControlByte EN discord bot
 ControlByte's discord bot for english server
